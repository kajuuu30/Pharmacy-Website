-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 23, 2021 at 08:07 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `sno` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `email_id` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sno`, `name`, `password`, `email_id`) VALUES
(2, 'kajal', '3017', 'kaju6434@gmail.com'),
(3, 'krish', '1710', 'kashu@gmail.com'),
(5, 'anvi', '308', 'anvi@gmail.com'),
(8, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE IF NOT EXISTS `pharmacy` (
  `sno` int(200) NOT NULL AUTO_INCREMENT,
  `brand` varchar(300) DEFAULT NULL,
  `medicine_name` varchar(300) DEFAULT NULL,
  `purpose` varchar(300) DEFAULT NULL,
  `description` longtext NOT NULL,
  `image` varchar(300) DEFAULT NULL,
  `price` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`sno`, `brand`, `medicine_name`, `purpose`, `description`, `image`, `price`) VALUES
(1, 'M-soliv', 'Ambroxol hydrochloride 15mg, Terbutaline Sulphate1.25g& guaiphenesin 50 mg syrup', 'Expectorant', 'dose=As Per Physician ,	Used for Relief of cough', 'M-solive.png', '85'),
(4, 'M-soliv', 'Paracetamol', 'Fever', ' As a person''s body temperature increases, they may feel cold until it levels off and stops rising. People describe this as “chills.”', 'Paracetamol.jpg', '100'),
(6, 'Cipla', 'Albandazole', 'Antiworm medication', 'Antiworm 400mg Tablet is an antiparasitic medication. It works by keeping the worms from absorbing sugar (glucose), thereby depleting their energy level. This causes the worms to die and treats your infection.', 'albandazole.jpg', '85'),
(8, 'M-soliv', 'Ambroxol hydrochloride 15mg, Terbutaline Sulphate1.25g& guaiphenesin 50 mg syrup', 'Expectorant', 'Waersdtgyuijkp', 'M-solive.png', '85'),
(9, 'Zyrtec', 'Cetirizine', 'allergy', 'dose 10mg', 'cetrizine.jpg', '18'),
(10, '', '', '', '', '', ''),
(11, 'Cipla', 'Stomach Pain Killer, 10', 'It is  used to relieve abdominal pain by reducing spasms in the stomach and intestines muscles.', 'Killer of stomach ached\r\n\r\nKiller of stomach ached\r\n\r\n', 'stomach pain.jpeg', '28'),
(12, 'Cipla', 'Stomach Pain Killer, 10', 'It is  used to relieve abdominal pain by reducing spasms in the stomach and intestines muscles.', 'Killer of stomach ached\r\n\r\nKiller of stomach ached\r\n\r\n', 'stomach pain.jpeg', '30'),
(13, 'Sofab LP', 'Cancer Medicine', 'The combination of ledipasvir and sofosbuvir is used alone or in combination with ribavirin (Copegus, Rebetol, Ribasphere, others) to treat certain types of chronic hepatitis C (an ongoing viral infection that damages the liver) in adults and children 3 years of age and older.', 'We can provide to you Sofab LP. It is used in the treatment of chronic hepatitis C virus (HCV) infecton.', '', '25000'),
(14, 'Dindayal Ayurved Bhawan', 'Ayurevdic Supari Pak, 250gm, Non Prescription', 'Dindayal Ayurved Bhawan MAnufactures Supari Pak.', 'Dindayal Ayurved Bhawan MAnufactures Supari Pak.', 'supari-pak.jpg', '216'),
(15, 'Cipla ', 'Ciplox 500 MG Tablet', 'Ciplox 500 MG Tablet is a broad-spectrum fluoroquinolone antibiotic used for the treatment of bacterial infections that affect the skin, joints, lungs, or urinary tract. It is effective against a large number of bacteria. It kills or prevents the growth of bacteria in the body. It is not effective a', 'Ciplox 511 MG Tablet is an antibiotic medicine that contains ciprofloxacin. It is used for the treatment of bacterial infections that affect your skin, joints, lungs, or urinary tract. It is effective against a large number of bacteria. It kills or prevents the growth of bacteria that causes infection. It should be used to treat bacterial infections only. It is not effective against infections caused by viruses. \r\n\r\nCommon side effects of Ciplox 511 MG Tablet are diarrhoea, stomach pain, headache, weakness, nausea, and vomiting. Ciplox 511 MG Tablet can cause muscle damage, usually in your ankle. Once an antibiotic is started, it is always recommended to finish the entire course of treatment to prevent bacterial resistance. \r\n\r\nYou can take Ciplox 511 MG Tablet with or without food. For the ease of remembering, take Ciplox 511 MG Tablet around the same time every day. Take Ciplox 511 MG Tablet 1-2 hours before or after taking any antacids as they increase the time takes for this medicine to show its effect. Take Ciplox 511 MG Tablet 2 hours before/after taking any dairy products as they can affect its absorption and decrease its beneficial effects.\r\n\r\nCiplox 511 MG Tablet should be avoided during pregnancy due to the risk of adverse effects on developing joints of the foetus. Ciplox 511 MG Tablet is not known to be harmful but it can pass into breast milk in small amounts, so if you are breastfeeding it is advised to consult your doctor before using it. Avoid Ciplox 511 MG Tablet if you have kidney disease or tendon issues as it can worsen your condition. ', 'ciplox.jpg', '36.66'),
(16, 'Cipla', 'Cosart 50mg tablet', 'High blood pressure (hypertension), Prevention of heart failure', 'COSART 51MG TABLET is used to treat high blood pressure and prevent heart failure. COSART 51MG TABLET is a angiotensin II receptor blocker that blocks the action of a hormone called angiotensin II in the body that causes narrowing of blood vessels leading to high blood pressure. Thereby, lowers high blood pressure by widening and relaxing blood vessels.', 'cosart.jpg', '48'),
(17, 'Cipla', 'Cipla Dytor Tablet', 'Torsemide', 'Dytor Tablet belongs to a group of medicines called diuretics or water tablets. It is effective to reduce the swelling (edema) caused by too much water in the body in people who have heart failure, liver disease or kidney disease. This drug is also used to cure high blood pressure.', 'dytor.jpg', '49'),
(18, 'Cipla', '20 Ml Cipla Cipremi Remdesivir 100 Mg', 'Corona treatment', 'Cipremi Remdesivir is a medicine that can help treat SARS-CoV-2. It can decrease the number of SARS-CoV-2 viruses in the body to help improve your lung function as well as your breathing.', 'cipremi.png', '2500'),
(19, 'Cipla', 'oral rehydration salts ip', 'dehydration', 'Restores body fluids & electrolytes lost due to dehydration.', 'ors.jpg', '35'),
(20, 'sun pharma', 'OXOFERIN', 'Purpose Wound severity  • Necrotic tissues • Infection & inflammation', '', 'Oxoferinplus.png', '127');

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE IF NOT EXISTS `query` (
  `sno` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `email_id` varchar(300) DEFAULT NULL,
  `message` varchar(200) NOT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`sno`, `name`, `email_id`, `message`) VALUES
(2, 'krish', 'kaju6434@gmail.com', ''),
(3, 'anvi', 'anvi@gmail.com', 'hi anvi'),
(5, 'krish', 'krish@gmail.com', 'hi krish'),
(6, 'neetu', 'neetu@gmail.com', 'hi neetu'),
(7, 'dilpreet', 'dilpreet@gmail.com', 'hlo dilpeet\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `s_no` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `contact_number` varchar(300) NOT NULL,
  `email_id` varchar(300) DEFAULT NULL,
  `city` varchar(300) NOT NULL,
  `DOB` varchar(300) NOT NULL,
  `state` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  PRIMARY KEY (`s_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`s_no`, `name`, `password`, `contact_number`, `email_id`, `city`, `DOB`, `state`, `address`) VALUES
(11, 'kajal yadav', '7777', '9877496425', 'kaju6434@gmial.com', 'Sangrur', '2021-08-13', 'punjab', 'dtry'),
(12, 'Navjot Kaur ', '0000', '9877496425', 'navu@gmail.com', 'patiala', '2021-08-15', 'punjab', 'qwzretxdcyfgvbhnujimk ,'),
(13, 'dilpreet', '555', '1234567890', 'dilpreet@gmail.com', 'patiala', '2021-07-27', 'punjab', 'xfgchvjb'),
(14, 'simmi ', '999', '098765409876', 'simran@gmail.com', 'patiala', '2021-08-29', 'punjab', 'nkn'),
(15, '', '', '', '', '', '', '', '');
