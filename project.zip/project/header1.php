 Marksheet Table 
<table border="3px" cellspacing="10px" cellpadding="10px">
<tr>
<td><b>1</b></td> 
<td><strong>2</strong></td> 
<th>3</th>
<th>4</th>
<th>5</th>
</tr
<tr>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
</tr>
</table>